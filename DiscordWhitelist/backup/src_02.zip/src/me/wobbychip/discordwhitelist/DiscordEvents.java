package me.wobbychip.discordwhitelist;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.guild.member.GuildMemberRoleRemoveEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class DiscordEvents extends ListenerAdapter {
	public void onGuildMemberRoleRemove(GuildMemberRoleRemoveEvent event) {
		if (!Main.plugin.getConfig().getBoolean("Enabled")) { return; }
		if (!event.getGuild().getId().equalsIgnoreCase(Main.guild.getId())) { return; }
		if (!event.getRoles().get(0).getId().equalsIgnoreCase(Main.roleID)) { return; }

		Player player = Bukkit.getServer().getPlayer(event.getMember().getEffectiveName());
		if (Utils.checkPermissions(player, "dwl.bypass")) { return; }

		if (player != null) {
    		Bukkit.getScheduler().runTask(Main.plugin, new Runnable() {
    			public void run() {
    				player.kickPlayer(Utils.getKickMessage(player.getName()));
    			}
    		});
		}
	}

	public void onMessageReceived(MessageReceivedEvent event) {
		if (!Main.plugin.getConfig().getBoolean("Enabled")) { return; }
		if (!event.getGuild().getId().equalsIgnoreCase(Main.guild.getId())) { return; }
		if (!event.getChannel().getId().equalsIgnoreCase(Main.channelID)) { return; }
		if (!Utils.hasRole(event.getMember(), Main.roleID)) { return; }

		String[] splited = event.getMessage().getContentRaw().split("\\s+");
		if (splited.length < 2) { return; }

		if (splited[0].equalsIgnoreCase("!verify")) {
			if (!splited[1].matches("^[a-zA-Z0-9_]{2,16}$")) {
				Utils.sendEmbed(event.getChannel(), "The username does not match parameters.");
				return;
			}

			Main.config.getConfig().set("whitelisted." + splited[1], event.getAuthor().getId());
			Main.config.Save();

			String message = "Account " + splited[1] + " is now linked with <@" + event.getAuthor().getId() + ">!";
			Utils.sendEmbed(event.getChannel(), message);
		}
	}
}
