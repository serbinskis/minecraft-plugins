package me.wobbychip.discordwhitelist;

import java.awt.Color;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.Role;

public class Utils {
	static int randomRange(int min, int max) {
		return new Random().nextInt((max - min) + 1) + min;
	}

	static String getString(String arg0) {
		return Main.plugin.getConfig().getString(arg0);
	}

	public static void sendMessage(String message) {
		Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
	}

	public static void sendMessage(CommandSender sender, String message) {
		sender.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
	}

	static boolean checkPermissions(CommandSender sender, String permission) {
		if (sender instanceof Player) {
			Player player = (Player) sender;
			if (!player.hasPermission(permission)) {
				sendMessage(sender, getString("permissionMessage"));
				return false;
			}
		}

		return true;
	}

	public static String getKickMessage(String name) {
		String replacedMessage = Utils.getString("kickMessage");

		if (!Main.config.getConfig().contains("whitelisted." + name)) {
			replacedMessage += Utils.getString("verifyMessage").replaceAll("%username", name);
		}

		replacedMessage = replacedMessage.replaceAll("%n", "\n");
		return ChatColor.translateAlternateColorCodes('&', replacedMessage);
	}

	static boolean hasRole(Member member, String roleID) {
		List<Role> roles = member.getRoles();

		for (int i = 0; i < roles.size(); i++) {
			if (roles.get(i).getId().equalsIgnoreCase(roleID)) {
				return true;
			}
		}

		return false;
	}

	public static boolean isPlayerWhitelisted(String name) {
		if (Main.guild == null) {
			Utils.sendMessage(Utils.getString("guildException"));
			return false;
		}

		//Get discord ID from minecraft UUID
		//Check if discord user has needed role
		String id = Main.config.getConfig().getString("whitelisted." + name);
		if (id == null) { return false; }
		Utils.sendMessage("ID -> " + id);
		Member member = Main.guild.getMemberById(id);
		Utils.sendMessage("member -> " + member.getEffectiveName());
		boolean hasRole = (member != null) ? hasRole(member, Main.roleID) : false;

		//If discord user doesn't have role remove from whitelist
		if (!hasRole) {
			Main.config.getConfig().set("whitelisted." + uuid.toString(), null);
			Main.config.getConfig().set("verify." + uuid.toString(), randomRange(10000, 99999));
		}

		Main.config.Save();
		return hasRole;
	}

	public static void sendEmbed(MessageChannel channel, String message) {
		EmbedBuilder embed = new EmbedBuilder();
		embed.setColor(new Color(0x0099ff));
		embed.setDescription(message);
		channel.sendMessageEmbeds(embed.build()).queue();
	}
}
